package com.and.mindeaseapp.data

data class onBoardingPage (
    val title:  String = "",
    val description: String = " ",
    val imageRes: Int = 0
)